#!/system/bin/sh

# NoADS_RU Hosts Magisk Module uninstall script

MODDIR=${0%/*}

# Remove the custom hosts file
rm -f "$MODDIR/system/etc/hosts"

# Remove config
rm -f "$MODDIR/config.txt"

# Restore original hosts if we can
if [ -f /system/etc/hosts.org 2>/dev/null ] || [ -f /system/etc/hosts ]; then
    mount -o remount,rw /system 2>/dev/null
    # Magisk will handle the unmount, we just need to ensure
    # the module's hosts file is removed from the overlay
    mount -o remount,ro /system 2>/dev/null
fi
