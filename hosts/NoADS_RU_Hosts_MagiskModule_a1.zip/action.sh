#!/system/bin/sh

# NoADS_RU Hosts Magisk Module - Action Script
# Triggered by the Action button in Magisk Manager

MODDIR=${0%/*}
CONFIG_FILE="$MODDIR/config.txt"
HOSTS_FILE="$MODDIR/system/etc/hosts"

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------
echo_magisk() {
    echo "$@"
}

download_file() {
    url="$1"
    file="$2"
    if command -v curl >/dev/null 2>&1; then
        curl -sLo "$file" "$url"
    elif command -v wget >/dev/null 2>&1; then
        wget -qO "$file" "$url"
    elif busybox wget -qO "$file" "$url" 2>/dev/null; then
        :
    else
        echo_magisk "ERROR: curl/wget not found"
        return 1
    fi
}

read_config() {
    BLOCKER=0
    BLOCKERFL=0
    BYPASS=0
    BYPASS2=0
    [ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE"
}

write_config() {
    cat > "$CONFIG_FILE" <<EOF
# NoADS_RU configuration
blocker=${BLOCKER:-0}
blockerFL=${BLOCKERFL:-0}
bypass=${BYPASS:-0}
bypass2=${BYPASS2:-0}
EOF
}

download_and_merge() {
    TMPDIR="/dev/tmp/noads_ru_action"
    rm -rf "$TMPDIR"
    mkdir -p "$TMPDIR"

    OK=0

    if [ "$BLOCKER" = "1" ]; then
        echo_magisk "  Downloading blocker.txt ..."
        download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/blocker.txt" "$TMPDIR/blocker.txt"
        [ -s "$TMPDIR/blocker.txt" ] && OK=$((OK + 1)) && echo_magisk "  OK" || echo_magisk "  FAILED"
    fi
    if [ "$BLOCKERFL" = "1" ]; then
        echo_magisk "  Downloading blocker.FLtxt ..."
        download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/blocker.FLtxt" "$TMPDIR/blocker.FLtxt"
        [ -s "$TMPDIR/blocker.FLtxt" ] && OK=$((OK + 1)) && echo_magisk "  OK" || echo_magisk "  FAILED"
    fi
    if [ "$BYPASS" = "1" ]; then
        echo_magisk "  Downloading bypass.txt ..."
        download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/bypass.txt" "$TMPDIR/bypass.txt"
        [ -s "$TMPDIR/bypass.txt" ] && OK=$((OK + 1)) && echo_magisk "  OK" || echo_magisk "  FAILED"
    fi
    if [ "$BYPASS2" = "1" ]; then
        echo_magisk "  Downloading bypass2.txt ..."
        download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/bypass2.txt" "$TMPDIR/bypass2.txt"
        [ -s "$TMPDIR/bypass2.txt" ] && OK=$((OK + 1)) && echo_magisk "  OK" || echo_magisk "  FAILED"
    fi

    if [ "$OK" -eq 0 ]; then
        echo_magisk "  ERROR: No files downloaded"
        rm -rf "$TMPDIR"
        return 1
    fi

    SOURCES=""
    [ "$BLOCKER" = "1" ]   && SOURCES="$SOURCES blocker"
    [ "$BLOCKERFL" = "1" ] && SOURCES="$SOURCES blockerFL"
    [ "$BYPASS" = "1" ]    && SOURCES="$SOURCES bypass"
    [ "$BYPASS2" = "1" ]   && SOURCES="$SOURCES bypass2"

    mkdir -p "$(dirname "$HOSTS_FILE")"
    {
        echo "# NoADS_RU merged hosts file"
        echo "#"
        echo "# Host lists used:$SOURCES"
        echo ""
        echo "127.0.0.1 localhost"
        echo "::1 localhost"
        echo ""
    } > "$HOSTS_FILE"

    for f in "$TMPDIR"/blocker.txt "$TMPDIR"/blocker.FLtxt "$TMPDIR"/bypass.txt "$TMPDIR"/bypass2.txt; do
        [ -f "$f" ] && grep -v '^#' "$f" | grep -v '^[[:space:]]*$' >> "$HOSTS_FILE"
    done

    ENTRIES=$(grep -c '^[0-9]' "$HOSTS_FILE" 2>/dev/null || echo "?")
    echo_magisk "  Total entries: $ENTRIES"

    rm -rf "$TMPDIR"
    return 0
}

apply_hosts() {
    if [ -f "$HOSTS_FILE" ]; then
        cp -f "$HOSTS_FILE" /system/etc/hosts 2>/dev/null || \
        mount -o remount,rw /system 2>/dev/null && \
        cp -f "$HOSTS_FILE" /system/etc/hosts && \
        mount -o remount,ro /system 2>/dev/null
        echo_magisk "  Hosts file applied to /system/etc/hosts"
    fi
}

# ---------------------------------------------------------------------------
# Key input
# ---------------------------------------------------------------------------
wait_key() {
    while true; do
        key=$(/system/bin/getevent -lqc 1 2>/dev/null | awk '{print $3}' | grep -E 'KEY_(VOLUME|POWER)')
        if [ -n "$key" ]; then
            echo "$key"
            return
        fi
        sleep 0.1
    done
}

select_option() {
    title="$1"
    shift
    count=0
    for _ in "$@"; do count=$((count + 1)); done
    current=0

    while true; do
        echo ""
        echo "  $title"
        echo "  --------------------------------"

        i=0
        for o in "$@"; do
            if [ "$i" -eq "$current" ]; then
                echo "  -> $o"
            else
                echo "     $o"
            fi
            i=$((i + 1))
        done

        echo ""
        echo "  [Vol+] Next  [Vol-] Select  [Lock] Cancel"

        key=$(wait_key)
        case "$key" in
            KEY_VOLUMEUP)
                current=$(( (current + 1) % count ))
                ;;
            KEY_VOLUMEDOWN)
                return $current
                ;;
            KEY_POWER|KEY_END|KEY_SLEEP)
                return 255
                ;;
        esac
    done
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
echo ""
echo "  NoADS_RU Action Menu"
echo "  ===================="
echo ""

read_config

while true; do
    ACTIVE_LISTS=""
    [ "$BLOCKER" = "1" ]   && ACTIVE_LISTS="$ACTIVE_LISTS blocker"
    [ "$BLOCKERFL" = "1" ] && ACTIVE_LISTS="$ACTIVE_LISTS blockerFL"
    [ "$BYPASS" = "1" ]    && ACTIVE_LISTS="$ACTIVE_LISTS bypass"
    [ "$BYPASS2" = "1" ]   && ACTIVE_LISTS="$ACTIVE_LISTS bypass2"
    [ -z "$ACTIVE_LISTS" ] && ACTIVE_LISTS="(none)"

    echo ""
    echo "  Current lists:$ACTIVE_LISTS"
    echo ""

    select_option "Action:" "Update existing rules" "Add new rules" "Remove rules" "Replace lists" "Exit"
    action=$?

    # Save current config for rollback
    OLD_BLOCKER=$BLOCKER
    OLD_BLOCKERFL=$BLOCKERFL
    OLD_BYPASS=$BYPASS
    OLD_BYPASS2=$BYPASS2

    case $action in
        # --- Update ---
        0)
            echo ""
            echo "  Updating existing rules..."
            if download_and_merge; then
                apply_hosts
                echo ""
                echo "  Update complete!"
            fi
            ;;

        # --- Add ---
        1)
            echo ""
            ADD_OPTS=""
            [ "$BLOCKER" = "0" ]   && ADD_OPTS="$ADD_OPTS blocker"
            [ "$BLOCKERFL" = "0" ] && ADD_OPTS="$ADD_OPTS blockerFL"
            [ "$BYPASS" = "0" ]    && ADD_OPTS="$ADD_OPTS bypass"
            [ "$BYPASS2" = "0" ]   && ADD_OPTS="$ADD_OPTS bypass2"

            if [ -z "$ADD_OPTS" ]; then
                echo "  All lists are already active."
                continue
            fi

            # Build dynamic menu
            MENU_OPTS=""
            for name in $ADD_OPTS; do
                MENU_OPTS="$MENU_OPTS $name"
            done

            set -- $MENU_OPTS
            select_option "Available lists to add:" "$@"
            add_choice=$?

            if [ "$add_choice" -eq 255 ]; then
                echo "  Cancelled"
                continue
            fi

            i=0
            for name in $ADD_OPTS; do
                if [ "$i" -eq "$add_choice" ]; then
                    case "$name" in
                        blocker)   BLOCKER=1 ;;
                        blockerFL) BLOCKERFL=1 ;;
                        bypass)    BYPASS=1 ;;
                        bypass2)   BYPASS2=1 ;;
                    esac
                    echo "  Added: $name"
                    break
                fi
                i=$((i + 1))
            done

            write_config
            if download_and_merge; then
                apply_hosts
                echo ""
                echo "  Add complete!"
            else
                BLOCKER=$OLD_BLOCKER
                BLOCKERFL=$OLD_BLOCKERFL
                BYPASS=$OLD_BYPASS
                BYPASS2=$OLD_BYPASS2
                write_config
                echo "  Rolled back to previous config."
            fi
            ;;

        # --- Remove ---
        2)
            echo ""
            REM_OPTS=""
            [ "$BLOCKER" = "1" ]   && REM_OPTS="$REM_OPTS blocker"
            [ "$BLOCKERFL" = "1" ] && REM_OPTS="$REM_OPTS blockerFL"
            [ "$BYPASS" = "1" ]    && REM_OPTS="$REM_OPTS bypass"
            [ "$BYPASS2" = "1" ]   && REM_OPTS="$REM_OPTS bypass2"

            if [ -z "$REM_OPTS" ]; then
                echo "  No active lists to remove."
                continue
            fi

            set -- $REM_OPTS
            select_option "Active lists:" "$@"
            rem_choice=$?

            if [ "$rem_choice" -eq 255 ]; then
                echo "  Cancelled"
                continue
            fi

            i=0
            for name in $REM_OPTS; do
                if [ "$i" -eq "$rem_choice" ]; then
                    case "$name" in
                        blocker)   BLOCKER=0 ;;
                        blockerFL) BLOCKERFL=0 ;;
                        bypass)    BYPASS=0 ;;
                        bypass2)   BYPASS2=0 ;;
                    esac
                    echo "  Removed: $name"
                    break
                fi
                i=$((i + 1))
            done

            write_config
            if download_and_merge; then
                apply_hosts
                echo ""
                echo "  Remove complete!"
            else
                BLOCKER=$OLD_BLOCKER
                BLOCKERFL=$OLD_BLOCKERFL
                BYPASS=$OLD_BYPASS
                BYPASS2=$OLD_BYPASS2
                write_config
                echo "  Rolled back to previous config."
            fi
            ;;

        # --- Replace ---
        3)
            echo ""
            echo "  Select list to replace:"
            REPLACE_OPTS=""
            REPLACE_KEYS=""
            [ "$BLOCKER" = "1" ] && REPLACE_OPTS="$REPLACE_OPTS blocker->blockerFL" && REPLACE_KEYS="$REPLACE_KEYS b2bf"
            [ "$BLOCKERFL" = "1" ] && REPLACE_OPTS="$REPLACE_OPTS blockerFL->blocker" && REPLACE_KEYS="$REPLACE_KEYS bf2b"
            [ "$BYPASS" = "1" ] && REPLACE_OPTS="$REPLACE_OPTS bypass->bypass2" && REPLACE_KEYS="$REPLACE_KEYS p2p2"
            [ "$BYPASS2" = "1" ] && REPLACE_OPTS="$REPLACE_OPTS bypass2->bypass" && REPLACE_KEYS="$REPLACE_KEYS p22p"

            if [ -z "$REPLACE_OPTS" ]; then
                echo "  No lists to replace."
                continue
            fi

            set -- $REPLACE_OPTS
            select_option "Replace:" "$@"
            rep_choice=$?

            if [ "$rep_choice" -eq 255 ]; then
                echo "  Cancelled"
                continue
            fi

            i=0
            for key in $REPLACE_KEYS; do
                if [ "$i" -eq "$rep_choice" ]; then
                    case "$key" in
                        b2bf)
                            BLOCKER=0; BLOCKERFL=1
                            echo "  Replaced blocker -> blockerFL"
                            ;;
                        bf2b)
                            BLOCKERFL=0; BLOCKER=1
                            echo "  Replaced blockerFL -> blocker"
                            ;;
                        p2p2)
                            BYPASS=0; BYPASS2=1
                            echo "  Replaced bypass -> bypass2"
                            ;;
                        p22p)
                            BYPASS2=0; BYPASS=1
                            echo "  Replaced bypass2 -> bypass"
                            ;;
                    esac
                    break
                fi
                i=$((i + 1))
            done

            write_config
            if download_and_merge; then
                apply_hosts
                echo ""
                echo "  Replace complete!"
            else
                BLOCKER=$OLD_BLOCKER
                BLOCKERFL=$OLD_BLOCKERFL
                BYPASS=$OLD_BYPASS
                BYPASS2=$OLD_BYPASS2
                write_config
                echo "  Rolled back to previous config."
            fi
            ;;

        # --- Exit ---
        4|255)
            echo ""
            echo "  Exiting."
            exit 0
            ;;
    esac
done
