#!/system/bin/sh

# NoADS_RU Hosts Magisk Module - Installation Script

MODPATH=${0%/*}

ui_print ""
ui_print "  NoADS_RU Hosts Magisk Module Installer"
ui_print "  ================================="
ui_print ""

# ---------------------------------------------------------------------------
# Volume key input
# ---------------------------------------------------------------------------
wait_key() {
    while true; do
        key=$(/system/bin/getevent -lqc 1 2>/dev/null | awk '{print $3}' | grep -E 'KEY_(VOLUME|POWER)')
        if [ -n "$key" ]; then
            echo "$key"
            return
        fi
        sleep 0.1
    done
}

# Returns: index (0-based) or 255 for cancel
select_option() {
    title="$1"
    shift
    options=""
    count=0
    for o in "$@"; do
        options="$options $o"
        count=$((count + 1))
    done
    current=0

    while true; do
        ui_print ""
        ui_print "  $title"
        ui_print "  --------------------------------"

        i=0
        for o in "$@"; do
            if [ "$i" -eq "$current" ]; then
                ui_print "  -> $o"
            else
                ui_print "     $o"
            fi
            i=$((i + 1))
        done

        ui_print ""
        ui_print "  [Vol+] Next  [Vol-] Select  [Lock] Cancel"

        key=$(wait_key)
        case "$key" in
            KEY_VOLUMEUP)
                current=$(( (current + 1) % count ))
                ;;
            KEY_VOLUMEDOWN)
                return $current
                ;;
            KEY_POWER|KEY_END|KEY_SLEEP)
                return 255
                ;;
        esac
    done
}

# ---------------------------------------------------------------------------
# Download helper
# ---------------------------------------------------------------------------
download_file() {
    url="$1"
    file="$2"
    if command -v curl >/dev/null 2>&1; then
        curl -sLo "$file" "$url"
    elif command -v wget >/dev/null 2>&1; then
        wget -qO "$file" "$url"
    elif busybox wget -qO "$file" "$url" 2>/dev/null; then
        :
    else
        ui_print "ERROR: curl/wget not found"
        return 1
    fi
}

# ---------------------------------------------------------------------------
# Step 1 – Select blocker list
# ---------------------------------------------------------------------------
ui_print "  Select blocker hosts list (for blocking ads):"
select_option "Blocker list:" blocker blockerFL Skip
blocker_choice=$?

BLOCKER_SELECTED=""
BLOCKERFL_SELECTED=""

if [ "$blocker_choice" -eq 0 ]; then
    BLOCKER_SELECTED=1
    ui_print "  Selected: blocker"
elif [ "$blocker_choice" -eq 1 ]; then
    BLOCKERFL_SELECTED=1
    ui_print "  Selected: blockerFL"
else
    ui_print "  Skipped blocker list"
fi

# ---------------------------------------------------------------------------
# Step 2 – Select bypass list
# ---------------------------------------------------------------------------
ui_print ""
ui_print "  Select bypass hosts list (for unblocking sites):"
select_option "Bypass list:" bypass bypass2 Skip
bypass_choice=$?

BYPASS_SELECTED=""
BYPASS2_SELECTED=""

if [ "$bypass_choice" -eq 0 ]; then
    BYPASS_SELECTED=1
    ui_print "  Selected: bypass"
elif [ "$bypass_choice" -eq 1 ]; then
    BYPASS2_SELECTED=1
    ui_print "  Selected: bypass2"
else
    ui_print "  Skipped bypass list"
fi

# ---------------------------------------------------------------------------
# Step 3 – Check if any list selected
# ---------------------------------------------------------------------------
if [ -z "$BLOCKER_SELECTED" ] && [ -z "$BLOCKERFL_SELECTED" ] && \
   [ -z "$BYPASS_SELECTED" ] && [ -z "$BYPASS2_SELECTED" ]; then
    ui_print ""
    ui_print "  No list selected. Aborting installation."
    abort "  No lists selected"
fi

# ---------------------------------------------------------------------------
# Step 4 – Download selected files
# ---------------------------------------------------------------------------
ui_print ""
ui_print "  Downloading selected hosts files..."
ui_print ""

TMPDIR="${TMPDIR:-/dev/tmp}"
WORKDIR="$TMPDIR/noads_ru_dl"
rm -rf "$WORKDIR"
mkdir -p "$WORKDIR"

DOWNLOAD_OK=0

if [ -n "$BLOCKER_SELECTED" ]; then
    ui_print "  Downloading blocker.txt ..."
    download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/blocker.txt" "$WORKDIR/blocker.txt"
    if [ -s "$WORKDIR/blocker.txt" ]; then
        DOWNLOAD_OK=$((DOWNLOAD_OK + 1))
        ui_print "  OK"
    else
        ui_print "  FAILED"
    fi
fi

if [ -n "$BLOCKERFL_SELECTED" ]; then
    ui_print "  Downloading blocker.FLtxt ..."
    download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/blocker.FLtxt" "$WORKDIR/blocker.FLtxt"
    if [ -s "$WORKDIR/blocker.FLtxt" ]; then
        DOWNLOAD_OK=$((DOWNLOAD_OK + 1))
        ui_print "  OK"
    else
        ui_print "  FAILED"
    fi
fi

if [ -n "$BYPASS_SELECTED" ]; then
    ui_print "  Downloading bypass.txt ..."
    download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/bypass.txt" "$WORKDIR/bypass.txt"
    if [ -s "$WORKDIR/bypass.txt" ]; then
        DOWNLOAD_OK=$((DOWNLOAD_OK + 1))
        ui_print "  OK"
    else
        ui_print "  FAILED"
    fi
fi

if [ -n "$BYPASS2_SELECTED" ]; then
    ui_print "  Downloading bypass2.txt ..."
    download_file "https://codeberg.org/Zalexanninev15/NoADS_RU/raw/hosts/bypass2.txt" "$WORKDIR/bypass2.txt"
    if [ -s "$WORKDIR/bypass2.txt" ]; then
        DOWNLOAD_OK=$((DOWNLOAD_OK + 1))
        ui_print "  OK"
    else
        ui_print "  FAILED"
    fi
fi

if [ "$DOWNLOAD_OK" -eq 0 ]; then
    ui_print "  ERROR: No files downloaded. Aborting."
    abort "  No files downloaded"
fi

# ---------------------------------------------------------------------------
# Step 5 – Merge hosts, strip comments
# ---------------------------------------------------------------------------
ui_print ""
ui_print "  Merging hosts files..."

HOSTS_FILE="$MODPATH/system/etc/hosts"
mkdir -p "$(dirname "$HOSTS_FILE")"

SOURCES=""
{
    echo "# NoADS_RU merged hosts file"
    echo "#"
    echo "# This file merges selected host lists from NoADS_RU."
    echo "# https://codeberg.org/Zalexanninev15/NoADS_RU"
    echo "#"
} > "$HOSTS_FILE"

[ -n "$BLOCKER_SELECTED" ]   && SOURCES="$SOURCES blocker"
[ -n "$BLOCKERFL_SELECTED" ] && SOURCES="$SOURCES blockerFL"
[ -n "$BYPASS_SELECTED" ]    && SOURCES="$SOURCES bypass"
[ -n "$BYPASS2_SELECTED" ]   && SOURCES="$SOURCES bypass2"

echo "# Host lists used:$SOURCES" >> "$HOSTS_FILE"
echo "" >> "$HOSTS_FILE"
echo "127.0.0.1 localhost" >> "$HOSTS_FILE"
echo "::1 localhost" >> "$HOSTS_FILE"
echo "" >> "$HOSTS_FILE"

for f in "$WORKDIR"/blocker.txt "$WORKDIR"/blocker.FLtxt "$WORKDIR"/bypass.txt "$WORKDIR"/bypass2.txt; do
    [ -f "$f" ] && grep -v '^#' "$f" | grep -v '^[[:space:]]*$' >> "$HOSTS_FILE"
done

ENTRIES=$(grep -c '^[0-9]' "$HOSTS_FILE" 2>/dev/null || echo "?")
ui_print "  Total entries: $ENTRIES"

# ---------------------------------------------------------------------------
# Step 6 – Write config
# ---------------------------------------------------------------------------
CONFIG_FILE="$MODPATH/config.txt"
{
    echo "# NoADS_RU configuration"
    echo "blocker=${BLOCKER_SELECTED:-0}"
    echo "blockerFL=${BLOCKERFL_SELECTED:-0}"
    echo "bypass=${BYPASS_SELECTED:-0}"
    echo "bypass2=${BYPASS2_SELECTED:-0}"
} > "$CONFIG_FILE"

# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------
rm -rf "$WORKDIR"

ui_print ""
ui_print "  Installation complete!"
ui_print "  Hosts lists used:$SOURCES"
ui_print "  Reboot for changes to take effect."
ui_print ""
