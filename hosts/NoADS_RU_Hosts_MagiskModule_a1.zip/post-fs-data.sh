#!/system/bin/sh

# NoADS_RU Hosts Magisk Module post-fs-data: ensure hosts file is applied

MODDIR=${0%/*}
HOSTS_FILE="$MODDIR/system/etc/hosts"

if [ -f "$HOSTS_FILE" ]; then
    mount -o remount,rw /system 2>/dev/null
    cp -f "$HOSTS_FILE" /system/etc/hosts 2>/dev/null
    mount -o remount,ro /system 2>/dev/null
fi
